"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  TrendingUp,
  LayoutGrid,
  CreditCard,
  CheckSquare,
  Target,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";

const mainNavigation = [
  { name: "Overview", href: "/dashboard", icon: LayoutGrid },
  { name: "Finances", href: "/dashboard/finances", icon: CreditCard },
  { name: "Habits", href: "/dashboard/habits", icon: CheckSquare },
  { name: "Goals", href: "/dashboard/goals", icon: Target },
  { name: "Reports", href: "/dashboard/reports", icon: BarChart3 },
];

const settingsNavigation = [
  { name: "Settings", href: "/dashboard/settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const user = api.getUser();

  const handleLogout = () => {
    api.logout();
    router.push("/");
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden bg-card"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-[220px] bg-[#0f172a] border-r border-[#1e293b] transition-transform lg:translate-x-0 flex flex-col",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex h-16 items-center gap-2 px-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <TrendingUp className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold text-foreground">
            LifeTrack
          </span>
        </div>

        {/* Main Navigation */}
        <nav className="flex-1 px-3 py-4">
          <p className="px-3 text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Personal Management
          </p>
          <ul className="flex flex-col gap-1">
            {mainNavigation.map((item) => {
              const isActive =
                item.href === "/dashboard"
                  ? pathname === "/dashboard"
                  : pathname.startsWith(item.href);
              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-[#1e293b] hover:text-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.name}
                  </Link>
                </li>
              );
            })}
          </ul>

          <p className="px-3 text-xs font-medium text-muted-foreground uppercase tracking-wider mt-6 mb-3">
            Settings
          </p>
          <ul className="flex flex-col gap-1">
            {settingsNavigation.map((item) => {
              const isActive = pathname.startsWith(item.href);
              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-[#1e293b] hover:text-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Upgrade Card */}
        <div className="mx-3 mb-4 rounded-lg bg-[#1e293b] p-4">
          <p className="text-sm text-foreground mb-1">
            Unlock advanced analytics and unlimited habits.
          </p>
          <Link
            href="/dashboard/settings"
            className="text-sm text-primary hover:underline inline-flex items-center gap-1"
          >
            Upgrade Now <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        {/* User Profile */}
        <div className="border-t border-[#1e293b] p-3">
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">
              {user?.name?.charAt(0) || "A"}S
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {user?.name || "Alex Silva"}
              </p>
              <Badge
                variant="secondary"
                className="bg-primary/20 text-primary text-xs px-1.5 py-0 h-5"
              >
                Pro Plan
              </Badge>
            </div>
            <button
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
